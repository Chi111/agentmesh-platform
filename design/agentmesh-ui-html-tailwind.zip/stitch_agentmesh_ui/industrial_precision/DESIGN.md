---
name: Industrial Precision
colors:
  surface: '#FFFFFF'
  surface-dim: '#d8dbd6'
  surface-bright: '#f8faf5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4ef'
  surface-container: '#ecefea'
  surface-container-high: '#e7e9e4'
  surface-container-highest: '#e1e3de'
  on-surface: '#191c1a'
  on-surface-variant: '#45474b'
  inverse-surface: '#2e312e'
  inverse-on-surface: '#eff1ec'
  outline: '#76777b'
  outline-variant: '#c6c6cb'
  surface-tint: '#5b5e66'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#181c22'
  on-primary-container: '#80848c'
  inverse-primary: '#c3c6cf'
  secondary: '#00687b'
  on-secondary: '#ffffff'
  secondary-container: '#50dcff'
  on-secondary-container: '#005f71'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#131f00'
  on-tertiary-container: '#659100'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dfe2eb'
  primary-fixed-dim: '#c3c6cf'
  on-primary-fixed: '#181c22'
  on-primary-fixed-variant: '#43474e'
  secondary-fixed: '#afecff'
  secondary-fixed-dim: '#48d7f9'
  on-secondary-fixed: '#001f27'
  on-secondary-fixed-variant: '#004e5d'
  tertiary-fixed: '#b9f54c'
  tertiary-fixed-dim: '#9ed830'
  on-tertiary-fixed: '#131f00'
  on-tertiary-fixed-variant: '#354e00'
  background: '#f8faf5'
  on-background: '#191c1a'
  surface-variant: '#e1e3de'
  text-primary: '#15191E'
  text-secondary: '#667078'
  border-base: '#DCE3E1'
  success: '#2CB67D'
  warning: '#F4A340'
  danger: '#E25555'
typography:
  display-lg:
    fontFamily: JetBrains Mono
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: JetBrains Mono
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-md:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  title-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: '1.5'
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: '1.4'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style

This design system is defined by an **Industrial-grade** aesthetic, prioritizing technical precision, clarity, and structural rigor. It is designed for high-stakes environments where accuracy is paramount and visual noise must be eliminated. The style draws heavily from **Minimalism** and **Modern Corporate** influences, but with a sharper, more "instrument-like" feel.

The emotional response should be one of absolute reliability and focused execution. The interface feels like a professional terminal or a high-end engineering tool—utilitarian yet refined. Large amounts of white space on a warm canvas provide breathing room for complex data, while high-contrast graphite elements anchor the user's attention to critical actions.

## Colors

The color strategy is strictly functional, stripping away decorative hues (purples, magentas) in favor of a palette that mirrors industrial hardware.

- **Primary (Graphite):** Used for the most critical UI anchors: main navigation, primary buttons, and heavy headings.
- **Background (Warm Canvas):** A soft, off-white foundation that reduces eye strain compared to pure white, providing a sophisticated backdrop for "Surface" elements.
- **Signal Cyan:** Reserved for the "Meshline," interactive links, information states, and active progress indicators. It represents the "data flow" within the system.
- **Acid Lime:** A high-visibility "Signal" color used sparingly (max 3% coverage). It is strictly for validation status and highlighting active executions.
- **Meshline Gradient:** A signature visual element using a linear gradient from Signal Cyan to Acid Lime, representing the transition from information to action.

## Typography

Typography is used as a functional tool for categorization. The design system employs a dual-font strategy:

- **JetBrains Mono** is used for headings, labels, and technical data. This monospaced influence reinforces the industrial and precise nature of the system.
- **Inter** is used for body copy and general interface text to ensure maximum readability and a clean, professional appearance.

All headings should be set in Graphite (#0D1117). Labels should often be set in uppercase with increased letter spacing to differentiate them from interactive text.

## Layout & Spacing

The layout is governed by a **Fixed Grid** philosophy on desktop to maintain alignment across complex data sets, switching to a fluid model for mobile.

- **Grid System:** A 12-column grid with a fixed maximum width of 1440px. 
- **Rhythm:** A strict 8px square grid ensures every element is aligned to a predictable increment.
- **Mobile Adaptivity:** At 768px and below, the grid collapses to 4 columns. Margins reduce to 16px to maximize screen real estate.
- **Alignment:** All containers must align to the grid edges to maintain the "Industrial" feel. Avoid centered layouts; prefer left-aligned, structured compositions.

## Elevation & Depth

To maintain the "Precise" and "Clean" brand pillars, this design system avoids soft ambient shadows. Instead, depth is communicated through **Tonal Layers** and **Bold Borders**.

- **Z-Axis Hierarchy:**
  - **Level 0 (Background):** Warm Canvas (#F5F7F2).
  - **Level 1 (Surface):** White (#FFFFFF) with a 1px Border (#DCE3E1). This is for cards and main content blocks.
  - **Level 2 (Interaction):** Elements being interacted with or selected receive a 1px Signal Cyan (#00B8D9) border.
  - **Level 3 (Overlay):** Modals and dropdowns use a sharp, 2px Graphite (#0D1117) border with a minimal, high-offset shadow (e.g., 4px 4px 0px rgba(0,0,0,0.05)) to suggest physical stacking without softness.

## Shapes

The shape language is **Soft (0.25rem)**. This slight rounding prevents the UI from feeling aggressive or "brutalist" while maintaining the geometry required for an industrial aesthetic.

- **Buttons & Inputs:** Use the base 0.25rem (4px) radius.
- **Cards:** Use the `rounded-lg` (0.5rem / 8px) radius to provide a clear container hierarchy.
- **Status Pills:** Despite the soft theme, badges and tags remain slightly rectangular rather than fully pill-shaped to stay consistent with the technical theme.

## Components

### Buttons
- **Primary:** Graphite (#0D1117) background with pure White text. No gradients.
- **Secondary:** Transparent background with 1px Graphite border and Graphite text.
- **Signal Action:** Signal Cyan background with Graphite text (for "Info" or "Next" style steps).

### Input Fields & Selects
- **Default State:** 1px Border (#DCE3E1), White surface, Inter font.
- **Active/Selected State:** 1px Signal Cyan (#00B8D9) border. No glow or outer shadows.
- **Validation:** Use 1px Success or Danger borders.

### Meshline
The Meshline is a distinctive visual element used to connect related data nodes or indicate progress. It must always be a gradient from **Signal Cyan (#00B8D9)** to **Acid Lime (#B7F34A)**.

### Cards
Cards are White (#FFFFFF) with a 1px Border (#DCE3E1). Use JetBrains Mono for card headers to distinguish them from the body content inside.

### Status Indicators
- **Active Execution:** Acid Lime (#B7F34A) text or small indicator dot. Avoid using lime as a full background color.
- **Success/Warning/Danger:** Use semantic colors for text and icons. Backgrounds for badges should be highly desaturated versions of the semantic color (90% lightness).

### Progress Bars
Track is Border color (#DCE3E1); Indicator is the Signal Cyan to Acid Lime gradient.